#include <iostream>
#include <iomanip>
#include <limits>
#include <sstream>

using namespace std;

class Clock {
private:
    int hour;
    int minute;
    int second;

public:
    // Constructor to initialize clock with given time
    Clock(int h = 0, int m = 0, int s = 0) : hour(h), minute(m), second(s) {}

    // Function to add an hour to the clock
    void addHour() {
        hour = (hour + 1) % 24;
    }

    // Function to add a minute to the clock
    void addMinute() {
        minute = (minute + 1) % 60;
    }

    // Function to add a second to the clock
    void addSecond() {
        second = (second + 1) % 60;
    }

    // Function to display the time in 12-hour format
    void display12Hour() {
        cout << setw(2) << setfill('0') << (hour % 12 == 0 ? 12 : hour % 12) << ":"
            << setw(2) << setfill('0') << minute << ":"
            << setw(2) << setfill('0') << second << " "
            << (hour < 12 ? "AM" : "PM") << endl;
    }

    // Function to display the time in 24-hour format
    void display24Hour() {
        cout << setw(2) << setfill('0') << hour << ":"
            << setw(2) << setfill('0') << minute << ":"
            << setw(2) << setfill('0') << second << endl;
    }
};

// Function to parse the time string in the format "HH:MM:SS"
bool parseTime(const string& timeStr, int& hour, int& minute, int& second) {
    stringstream ss(timeStr);
    char discard;

    if (ss >> hour >> discard >> minute >> discard >> second)
        return true;
    else
        return false;
}

int main() {
    cout << "Welcome to Keith Castellanos Clock!" << endl;

    int initialHour, initialMinute, initialSecond;
    string initialTimeStr;

    cout << "Enter initial time (e.g., 11:13:02): ";
    cin >> initialTimeStr;

    // Parse the initial time string
    if (!parseTime(initialTimeStr, initialHour, initialMinute, initialSecond)) {
        cout << "Invalid time format! Please enter time in the format HH:MM:SS\n";
        return 1;
    }

    Clock clock1(initialHour, initialMinute, initialSecond);
    Clock clock2(initialHour, initialMinute, initialSecond);

    char choice;
    do {
        cout << "\nMENU\n";
        cout << "1. Add hour\n";
        cout << "2. Add minute\n";
        cout << "3. Add second\n";
        cout << "4. Display 12-hour clock\n";
        cout << "5. Display 24-hour clock\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        // Clear input buffer
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (choice) {
        case '1':
            clock1.addHour();
            clock2.addHour();
            break;
        case '2':
            clock1.addMinute();
            clock2.addMinute();
            break;
        case '3':
            clock1.addSecond();
            clock2.addSecond();
            break;
        case '4':
            cout << "12-Hour Clock 1: ";
            clock1.display12Hour();
            cout << "12-Hour Clock 2: ";
            clock2.display12Hour();
            break;
        case '5':
            cout << "24-Hour Clock 1: ";
            clock1.display24Hour();
            cout << "24-Hour Clock 2: ";
            clock2.display24Hour();
            break;
        case '6':
            cout << "Exiting program...\n";
            break;
        default:
            cout << "Invalid choice! Please try again.\n";
        }
    } while (choice != '6');

    return 0;
}
